/* ====== CONFIGURACIÓN (edita aquí) ====== */
const CONFIG = {
  whatsapp: "573208133818",     // +57 320 813 3818
  instagram: "https://www.instagram.com/info.villatours.huila",
  mapa: "https://maps.app.goo.gl/h74zWURozsB6zpQn8",   // ubicación de la agencia (Google Maps)
  horario: "",   // opcional: ej. "Lunes a sábado, 8:00 a. m. a 6:00 p. m." (si lo dejas vacío no se muestra)
  rnt: "",       // opcional: número del Registro Nacional de Turismo (se muestra en el pie de página)
  // VIDEO principal de la portada (archivos dentro de la carpeta video/)
  video: "video/destinos.mp4",
  poster: "video/portada.jpg",
  // Fotos de la galería (están en images/galeria/; agrega o quita nombres aquí):
  fotos: ["foto-01.jpg", "foto-02.jpg", "foto-03.jpg", "foto-04.jpg", "foto-05.jpg", "foto-06.jpg", "foto-07.jpg", "foto-08.jpg", "foto-09.jpg", "foto-10.jpg", "foto-11.jpg", "foto-12.jpg", "foto-13.jpg", "foto-14.jpg", "foto-15.jpg", "foto-16.jpg", "foto-17.jpg", "foto-18.jpg", "foto-19.jpg", "foto-20.jpg", "foto-21.jpg", "foto-22.jpg", "foto-23.jpg", "foto-24.jpg", "foto-25.jpg", "foto-26.jpg", "foto-27.jpg", "foto-28.jpg", "foto-29.jpg", "foto-30.jpg"],
  // HOSPEDAJE: un bloque por hotel. destino: "agustin", "rivera" o "villavieja".
  // carpeta: subcarpeta dentro de images/hoteles/   fotos: nombres de archivo (la primera es la portada)
  hoteles: [
    { nombre: "Hotel Estorake", destino: "agustin", tipo: "Hotel", descripcion: "Hospedaje en San Agustín con habitaciones y zonas verdes.", servicios: ["Habitaciones", "Jardín"], precio: "Consultar precio", carpeta: "estorake", fotos: ["1.jpg","2.jpg","3.jpg","4.jpg"] },
    { nombre: "Finca El Cielo", destino: "agustin", tipo: "Finca hotel", descripcion: "Finca hotel en San Agustín con habitaciones, restaurante y zonas verdes.", servicios: ["Habitaciones", "Restaurante", "Zonas verdes"], precio: "Consultar precio", carpeta: "finca-el-cielo", fotos: ["1.jpg","2.jpg","3.jpg","4.jpg","5.jpg","6.jpg"] },
    { nombre: "Hotel Casa Mateo", destino: "rivera", tipo: "Hotel", descripcion: "Hotel en La Rivera con habitaciones, jardín y zonas de recreación.", servicios: ["Habitaciones", "Jardín", "Mesa de ping-pong"], precio: "Consultar precio", carpeta: "casa-mateo", fotos: ["1.jpg","2.jpg","3.jpg","4.jpg","5.jpg"] },
    { nombre: "Hotel Shaddai", destino: "villavieja", tipo: "Hotel", descripcion: "Hospedaje en Villavieja con piscina, terraza y zonas de descanso.", servicios: ["Piscina", "Terraza", "Zona de descanso"], precio: "Consultar precio", carpeta: "shaddai", fotos: ["1.jpg","2.jpg","3.jpg","4.jpg","5.jpg"] },
    { nombre: "Hotel Gold Suite", destino: "villavieja", tipo: "Hotel", descripcion: "Hospedaje en Villavieja con piscina y restaurante.", servicios: ["Piscina", "Restaurante", "Habitaciones"], precio: "Consultar precio", carpeta: "gold-suite", fotos: ["1.jpg","2.jpg","3.jpg","4.jpg","5.jpg"] },
    { nombre: "Hotel Villa Paraíso", destino: "villavieja", tipo: "Hotel", descripcion: "Hospedaje en Villavieja con piscina, restaurante y habitaciones.", servicios: ["Piscina", "Restaurante", "Habitaciones"], precio: "Consultar precio", carpeta: "villa-paraiso", fotos: ["1.jpg","2.jpg","3.jpg","4.jpg","5.jpg"] }
  ]
};
/* ======================================== */

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
// Rutas de archivos (en la vista previa se reemplazan por archivos incrustados)
const ruta = p => (window.IMG_PREVIEW && window.IMG_PREVIEW[p]) || p;

// WhatsApp: cada botón abre el chat con un mensaje listo
$$("[data-wa]").forEach(a => {
  const msg = a.dataset.wa || "Hola, quiero más información sobre los tours de Huila Mágico Tours";
  a.href = `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(msg)}`;
  a.target = "_blank"; a.rel = "noopener";
  a.addEventListener("click", () => reacciona("¡Genial! Te esperamos en WhatsApp."));
});

// Instagram
$$("[data-ig]").forEach(a => {
  a.href = CONFIG.instagram || "https://www.instagram.com/";
  a.target = "_blank"; a.rel = "noopener";
});

// Ubicación, horario y RNT
$$("[data-mapa]").forEach(a => { a.href = CONFIG.mapa; a.target = "_blank"; a.rel = "noopener"; });
if (CONFIG.horario) { const el = $("#horario"); el.hidden = false; $("span", el).textContent = CONFIG.horario; }
if (CONFIG.rnt) { const el = $("#rnt"); el.hidden = false; el.textContent = "RNT " + CONFIG.rnt; }
// Enlaces de destino del pie: activan el filtro de paquetes
$$("[data-filtro]").forEach(a => a.addEventListener("click", () => $(`#paquetes .chips button[data-f="${a.dataset.filtro}"]`)?.click()));
// Volver arriba
const arriba = $(".arriba");
addEventListener("scroll", () => { arriba.hidden = scrollY < 700; }, { passive: true });
arriba.onclick = () => scrollTo({ top: 0, behavior: matchMedia("(prefers-reduced-motion:reduce)").matches ? "auto" : "smooth" });

// Menú móvil
const burger = $(".burger"), menu = $("#menu");
burger.onclick = () => burger.setAttribute("aria-expanded", menu.classList.toggle("open"));
$$("#menu a").forEach(a => a.onclick = () => { menu.classList.remove("open"); burger.setAttribute("aria-expanded", "false"); });

// Video principal de la portada
const caja = $("#video"), vid = $("video", caja), vctl = $(".vctl");
function sinVideo() {   // si el video no carga, se muestra la imagen de portada
  caja.innerHTML = `<img src="${ruta(CONFIG.poster)}" alt="Paisaje del Huila">`;
  $("img", caja).onerror = () => { caja.innerHTML = '<div class="vacio"><svg><use href="#i-play"/></svg><p>Video de los 3 destinos</p></div>'; };
}
vid.onerror = sinVideo;
vid.poster = ruta(CONFIG.poster);
vid.src = ruta(CONFIG.video);
if (matchMedia("(prefers-reduced-motion:reduce)").matches) { vid.controls = true; vctl.remove(); }
else { vid.autoplay = true; vid.play().catch(() => {}); }
const icono = () => { $("use", vctl)?.setAttribute("href", vid.paused ? "#i-play" : "#i-pause"); vctl.setAttribute("aria-label", vid.paused ? "Reproducir video" : "Pausar video"); };
vid.onplay = icono; vid.onpause = icono;
vctl.onclick = () => { vid.paused ? vid.play() : vid.pause(); reacciona(vid.paused ? "¿Pausaste el video? Dale play cuando quieras." : "¡Eso! Que ruede el video."); };

// Filtro de paquetes
$$("#paquetes .chips button").forEach(b => b.onclick = () => {
  $$("#paquetes .chips button").forEach(x => x.classList.toggle("on", x === b));
  $$("#paquetes .grupo").forEach(g => g.hidden = b.dataset.f !== "todos" && g.dataset.cat !== b.dataset.f);
  reacciona(b.dataset.f === "todos" ? "Aquí tienes todos los paquetes." : `Paquetes de ${b.textContent}: ¡buena elección!`);
});

// Visor de fotos (lo usan la galería y los hoteles)
const grid = $(".galeria"), lb = $("#lb"), lbImg = $("img", lb);
let lbLista = [], abierta = 0;
function abrirLB(lista, n) {
  if (!lista.length) return;
  lbLista = lista; abierta = (n + lista.length) % lista.length;
  lbImg.src = lbLista[abierta].src; lbImg.alt = lbLista[abierta].alt;
  if (!lb.open) lb.showModal();
}
$("#lb .x").onclick = () => lb.close();
$("#lb .prev").onclick = () => abrirLB(lbLista, abierta - 1);
$("#lb .next").onclick = () => abrirLB(lbLista, abierta + 1);
lb.onclick = e => { if (e.target === lb) lb.close(); };
document.addEventListener("keydown", e => {
  if (!lb.open) return;
  if (e.key === "ArrowLeft") abrirLB(lbLista, abierta - 1);
  if (e.key === "ArrowRight") abrirLB(lbLista, abierta + 1);
});

// Galería
CONFIG.fotos.forEach((f, n) => {
  const b = document.createElement("button");
  b.className = "foto";
  const img = new Image();
  img.alt = "Foto " + (n + 1) + " de nuestros tours";
  img.loading = "lazy";
  img.src = ruta("images/galeria/" + f);
  img.onerror = () => { b.classList.add("vacia"); b.textContent = "Tu foto aquí"; b.onclick = null; };
  b.append(img);
  b.onclick = () => {
    const ok = $$(".foto:not(.vacia)");
    abrirLB(ok.map(x => ({ src: $("img", x).src, alt: $("img", x).alt })), ok.indexOf(b));
  };
  grid.append(b);
});

// Galería: se muestran 12 y el resto con "Ver más fotos"
const MAS = $("#masFotos"), FOTOS_ITEMS = $$(".foto"), VISIBLES = 12;
let galeriaAbierta = false;
function ajustaGaleria() {
  FOTOS_ITEMS.forEach((b, i) => b.hidden = !galeriaAbierta && i >= VISIBLES);
  MAS.hidden = FOTOS_ITEMS.length <= VISIBLES;
  MAS.textContent = galeriaAbierta ? "Ver menos fotos" : `Ver las ${FOTOS_ITEMS.length} fotos`;
}
MAS.onclick = () => { galeriaAbierta = !galeriaAbierta; ajustaGaleria(); if (!galeriaAbierta) $("#galeria").scrollIntoView(); };
ajustaGaleria();

// Hospedaje: hoteles agrupados por destino
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const GRUPOS = [["agustin", "San Agustín"], ["rivera", "La Rivera"], ["villavieja", "Villavieja"]];
const listaH = $(".hoteles");
GRUPOS.forEach(([id, lugar]) => {
  const hs = CONFIG.hoteles.filter(h => h.destino === id);
  if (!hs.length) return;
  const g = document.createElement("div");
  g.className = "grupo"; g.dataset.cat = id;
  g.innerHTML = `<h3 class="gt">${lugar}</h3><div class="cards"></div>`;
  hs.forEach(h => {
    const rutas = (h.fotos || []).map(f => ruta(`images/hoteles/${h.carpeta}/${f}`));
    const lista = rutas.map((s, i) => ({ src: s, alt: `${h.nombre}, foto ${i + 1}` }));
    const msg = `Hola, quiero más información de hospedaje: ${h.nombre} (${lugar})`;
    const art = document.createElement("article");
    art.className = "card";
    art.innerHTML = `
      <button class="thumb hotel" aria-label="Ver fotos de ${esc(h.nombre)}"><span class="ver">Ver ${rutas.length} fotos</span></button>
      <div class="body">
        <span class="lugar">${esc(lugar)}</span>
        <h4>${esc(h.nombre)}</h4>
        <span class="tipo">${esc(h.tipo)}</span>
        <p>${esc(h.descripcion)}</p>
        <ul class="servs">${(h.servicios || []).map(s => `<li>${esc(s)}</li>`).join("")}</ul>
        <p class="precio">${esc(h.precio || "Consultar precio")}</p>
        <a class="btn sm" target="_blank" rel="noopener" href="https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(msg)}"><svg><use href="#i-wa"/></svg>Más información</a>
      </div>`;
    const th = $(".thumb", art);
    if (rutas[0]) th.style.setProperty("--foto", `url("${rutas[0]}")`);
    th.onclick = () => abrirLB(lista, 0);
    $(".cards", g).append(art);
  });
  listaH.append(g);
});
$$("#hospedaje .chips button").forEach(b => b.onclick = () => {
  $$("#hospedaje .chips button").forEach(x => x.classList.toggle("on", x === b));
  $$("#hospedaje .grupo").forEach(g => g.hidden = b.dataset.f !== "todos" && g.dataset.cat !== b.dataset.f);
  reacciona(b.dataset.f === "todos" ? "Estos son todos los hoteles." : `Hoteles en ${b.textContent}. ¡Que descanses bien!`);
});

// Mascota: el megaterio conversa, guía y reacciona a lo que haces
const SECCIONES = {
  ".hero": ["¡Hola! Soy el megaterio, el perezoso gigante de la Tatacoa. Vamos con calma: te ayudo a elegir tu viaje.", "Mira el video: así se vive el Huila.", "Cuando quieras, toca el botón de Más información y hablamos por WhatsApp."],
  "#paquetes": ["Aquí están los paquetes, ordenados por destino. Toca un filtro para ver solo uno.", "Cada tarjeta tiene su botón de Más información: te lleva directo al WhatsApp.", "El paquete completo de Villavieja incluye desierto, estrellas, río y museo."],
  "#hospedaje": ["Un buen descanso también es parte del viaje. Toca la foto de un hotel para ver todas sus fotos.", "Los hoteles están ordenados por destino, igual que los paquetes."],
  "#galeria": ["Mira cómo se vive el Huila. Toca una foto para verla en grande.", "Puedes pasar las fotos con las flechas de tu teclado o con los botones."],
  "#contacto": ["Aquí está nuestro WhatsApp, el Instagram y la ubicación de la agencia.", "Toca Ubicación y se abre Google Maps para llegar."],
  "#reservar": ["¿Listo? Son tres pasos y el primero es escribirnos por WhatsApp.", "Sin afán: te respondemos con precio y disponibilidad."]
};
const DATOS = [
  "El Desierto de la Tatacoa no es un desierto de arena: es un bosque seco tropical con cañones rojos y grises.",
  "El río Magdalena es el más largo de Colombia, y en Villavieja puedes recorrerlo en lancha.",
  "El Parque Arqueológico de San Agustín es Patrimonio de la Humanidad de la UNESCO.",
  "Yo soy un megaterio: un perezoso terrestre gigante que pesaba varias toneladas. ¡Ahora me muevo despacito!",
  "En la Tatacoa se ven muchísimas estrellas de noche, por eso hay observatorio astronómico.",
  "Para el desierto lleva sombrero, bloqueador y agua. Y ropa abrigada para la noche de estrellas.",
  "En San Agustín hay muchas estatuas de piedra talladas por culturas antiguas.",
  "La Rivera es perfecta para descansar: aguas termales y naturaleza."
];
const mega = $(".megaterio"), globo = $(".globo");
const visitadas = new Set(), iMsg = {};
let callado = false, tGlobo, seccion = ".hero", ultimoDato = -1, nudges = 0, ultimaAccion = Date.now(), clicsRapidos = 0, ultimoClic = 0;
try { callado = sessionStorage.getItem("mega-callado") === "1"; } catch {}
const irA = sel => $(sel)?.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion:reduce)").matches ? "auto" : "smooth" });
const waLink = t => `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(t)}`;
function habla() { mega.classList.remove("habla"); void mega.offsetWidth; mega.classList.add("habla"); setTimeout(() => mega.classList.remove("habla"), 1600); }
function decir(texto, botones = [], ms = 7000) {
  globo.innerHTML = "";
  const p = document.createElement("p"); p.textContent = texto; globo.append(p);
  if (botones.length) {
    const fila = document.createElement("div"); fila.className = "acc";
    botones.forEach(([t, fn]) => {
      const b = document.createElement("button"); b.textContent = t;
      b.onclick = e => { e.stopPropagation(); ultimaAccion = Date.now(); fn(); };
      fila.append(b);
    });
    globo.append(fila);
  }
  globo.classList.add("on"); habla();
  clearTimeout(tGlobo);
  tGlobo = setTimeout(() => globo.classList.remove("on"), botones.length ? Math.max(ms, 14000) : ms);
}
function reacciona(texto) { if (!callado) decir(texto); }
function menuMega() {
  decir("¿En qué te ayudo?", [
    ["Ver paquetes", () => irA("#paquetes")],
    ["¿Dónde dormir?", () => irA("#hospedaje")],
    ["¿Dónde están?", () => irA("#contacto")],
    ["Dato curioso", dato],
    ["Más información", () => { window.open(waLink("Hola, quiero más información de Huila Mágico Tours"), "_blank", "noopener"); decir("¡Listo! Te esperamos en WhatsApp."); }],
    ["Ahora no", callar]
  ]);
}
function dato() {
  let i; do { i = Math.floor(Math.random() * DATOS.length); } while (i === ultimoDato);
  ultimoDato = i;
  decir(DATOS[i], [["Otro dato", dato], ["Menú", menuMega]]);
}
function callar() {
  callado = true;
  try { sessionStorage.setItem("mega-callado", "1"); } catch {}
  decir("Vale, me quedo calladito. Tócame cuando me necesites.", [], 3500);
}
function siguiente() {
  const lista = SECCIONES[seccion]; iMsg[seccion] = (iMsg[seccion] ?? 0) + 1;
  if (iMsg[seccion] < lista.length) decir(lista[iMsg[seccion]]); else { iMsg[seccion] = 0; menuMega(); }
}
mega.onclick = () => {
  const ahora = Date.now(); ultimaAccion = ahora;
  clicsRapidos = ahora - ultimoClic < 600 ? clicsRapidos + 1 : 1; ultimoClic = ahora;
  if (clicsRapidos >= 4) {
    clicsRapidos = 0; mega.classList.remove("mareado"); void mega.offsetWidth; mega.classList.add("mareado");
    setTimeout(() => mega.classList.remove("mareado"), 800);
    decir("¡Ay, me mareas! Con calma, que soy un perezoso.", [], 3500); return;
  }
  mega.classList.remove("saluda"); void mega.offsetWidth; mega.classList.add("saluda");
  setTimeout(() => mega.classList.remove("saluda"), 1400);
  const abierto = globo.classList.contains("on");
  if (abierto && globo.querySelector(".acc")) globo.classList.remove("on");
  else if (abierto) siguiente();
  else menuMega();
};
// Saluda según la sección que estás viendo (una vez por sección)
const visto = new IntersectionObserver(es => es.forEach(e => {
  if (!e.isIntersecting) return;
  const t = Object.keys(SECCIONES).find(s => e.target.matches(s));
  if (!t) return;
  seccion = t;
  if (!callado && !visitadas.has(t)) { visitadas.add(t); iMsg[t] = 0; decir(SECCIONES[t][0]); }
}), { rootMargin: "-45% 0px -50% 0px" });
Object.keys(SECCIONES).forEach(s => { const el = $(s); if (el) visto.observe(el); });
// Si llevas un rato sin hacer nada, te ofrece ayuda (máximo 2 veces)
["scroll", "pointerdown", "keydown"].forEach(ev => addEventListener(ev, () => { ultimaAccion = Date.now(); }, { passive: true }));
setInterval(() => {
  if (!callado && nudges < 2 && Date.now() - ultimaAccion > 35000 && !globo.classList.contains("on")) {
    nudges++; decir("¿Sigues por ahí? Tócame y te ayudo a elegir tu viaje.", [["Menú", menuMega]]);
  }
}, 10000);
